// ============================================================
// FreshCart — Express Server Entrypoint
// Agent 2: Backend  |  Agent 4: Integration (static serving)
// ============================================================

const express = require("express");
const cors = require("cors");
const path = require("path");

const productsRouter = require("./routes/products");
const cartRouter = require("./routes/cart");
const ordersRouter = require("./routes/orders");

const app = express();
const PORT = process.env.PORT || 3001;

// ── Middleware ──────────────────────────────────────
app.use(cors());
app.use(express.json());

// ── Serve frontend static files ────────────────────
app.use(express.static(path.join(__dirname, "..", "client")));

// ── API Routes ─────────────────────────────────────
app.use("/api/products", productsRouter);
app.use("/api/cart", cartRouter);
app.use("/api/orders", ordersRouter);

// ── Health check ───────────────────────────────────
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", name: "FreshCart API", version: "1.0.0" });
});

// ── SPA fallback — serve index.html for all other routes ──
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "client", "index.html"));
});

// ── Start ──────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
  ╔══════════════════════════════════════════╗
  ║                                          ║
  ║   🛒  FreshCart is running!              ║
  ║                                          ║
  ║   Local:  http://localhost:${PORT}          ║
  ║   API:    http://localhost:${PORT}/api      ║
  ║                                          ║
  ╚══════════════════════════════════════════╝
  `);
});
