// ============================================================
// FreshCart — Products API Routes
// Agent 2: Backend
// ============================================================

const express = require("express");
const router = express.Router();
const { products } = require("../models/data");

// GET /api/products — list all products, optional ?category= filter
router.get("/", (req, res) => {
  const { category, search } = req.query;
  let result = [...products];

  if (category && category !== "All") {
    result = result.filter(
      (p) => p.category.toLowerCase() === category.toLowerCase()
    );
  }

  if (search) {
    const q = search.toLowerCase();
    result = result.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
    );
  }

  res.json({ success: true, data: result, count: result.length });
});

// GET /api/products/:id — single product
router.get("/:id", (req, res) => {
  const product = products.find((p) => p.id === parseInt(req.params.id));
  if (!product) {
    return res.status(404).json({ success: false, error: "Product not found" });
  }
  res.json({ success: true, data: product });
});

// GET /api/products/categories/list — get unique categories
router.get("/categories/list", (req, res) => {
  const categories = [...new Set(products.map((p) => p.category))];
  res.json({ success: true, data: ["All", ...categories.sort()] });
});

module.exports = router;
