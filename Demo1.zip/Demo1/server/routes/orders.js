// ============================================================
// FreshCart — Orders API Routes
// Agent 2: Backend
// ============================================================

const express = require("express");
const router = express.Router();
const { cart, products, orders, getNextOrderId, clearCart } = require("../models/data");

// POST /api/orders — place an order from current cart
router.post("/", (req, res) => {
  if (cart.length === 0) {
    return res.status(400).json({ success: false, error: "Cart is empty" });
  }

  const orderItems = cart
    .map((item) => {
      const product = products.find((p) => p.id === item.productId);
      if (!product) return null;
      return {
        productId: item.productId,
        name: product.name,
        price: product.price,
        image: product.image,
        quantity: item.quantity,
        subtotal: +(product.price * item.quantity).toFixed(2),
      };
    })
    .filter(Boolean);

  const total = +orderItems.reduce((sum, i) => sum + i.subtotal, 0).toFixed(2);

  const order = {
    id: getNextOrderId(),
    items: orderItems,
    total,
    status: "confirmed",
    createdAt: new Date().toISOString(),
  };

  orders.push(order);
  clearCart();

  res.status(201).json({
    success: true,
    message: "Order placed successfully!",
    data: order,
  });
});

// GET /api/orders — list all orders
router.get("/", (req, res) => {
  res.json({
    success: true,
    data: orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    count: orders.length,
  });
});

// GET /api/orders/:id — single order
router.get("/:id", (req, res) => {
  const order = orders.find((o) => o.id === parseInt(req.params.id));
  if (!order) {
    return res.status(404).json({ success: false, error: "Order not found" });
  }
  res.json({ success: true, data: order });
});

module.exports = router;
