// ============================================================
// FreshCart — Cart API Routes
// Agent 2: Backend
// ============================================================

const express = require("express");
const router = express.Router();
const { cart, products, clearCart } = require("../models/data");

// Helper: enrich cart items with product details
function enrichCart() {
  return cart
    .map((item) => {
      const product = products.find((p) => p.id === item.productId);
      if (!product) return null;
      return {
        productId: item.productId,
        name: product.name,
        price: product.price,
        unit: product.unit,
        image: product.image,
        quantity: item.quantity,
        subtotal: +(product.price * item.quantity).toFixed(2),
      };
    })
    .filter(Boolean);
}

// GET /api/cart — get cart contents
router.get("/", (req, res) => {
  const items = enrichCart();
  const total = +items.reduce((sum, i) => sum + i.subtotal, 0).toFixed(2);
  res.json({ success: true, data: { items, total, count: items.length } });
});

// POST /api/cart — add item { productId, quantity }
router.post("/", (req, res) => {
  const { productId, quantity = 1 } = req.body;

  if (!productId) {
    return res.status(400).json({ success: false, error: "productId is required" });
  }

  const product = products.find((p) => p.id === productId);
  if (!product) {
    return res.status(404).json({ success: false, error: "Product not found" });
  }

  const existing = cart.find((i) => i.productId === productId);
  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({ productId, quantity });
  }

  const items = enrichCart();
  const total = +items.reduce((sum, i) => sum + i.subtotal, 0).toFixed(2);
  res.status(201).json({
    success: true,
    message: `${product.name} added to cart`,
    data: { items, total, count: items.length },
  });
});

// PUT /api/cart/:productId — update quantity
router.put("/:productId", (req, res) => {
  const pid = parseInt(req.params.productId);
  const { quantity } = req.body;

  if (!quantity || quantity < 0) {
    return res.status(400).json({ success: false, error: "Valid quantity is required" });
  }

  const idx = cart.findIndex((i) => i.productId === pid);
  if (idx === -1) {
    return res.status(404).json({ success: false, error: "Item not in cart" });
  }

  if (quantity === 0) {
    cart.splice(idx, 1);
  } else {
    cart[idx].quantity = quantity;
  }

  const items = enrichCart();
  const total = +items.reduce((sum, i) => sum + i.subtotal, 0).toFixed(2);
  res.json({ success: true, data: { items, total, count: items.length } });
});

// DELETE /api/cart/:productId — remove item
router.delete("/:productId", (req, res) => {
  const pid = parseInt(req.params.productId);
  const idx = cart.findIndex((i) => i.productId === pid);
  if (idx === -1) {
    return res.status(404).json({ success: false, error: "Item not in cart" });
  }

  cart.splice(idx, 1);

  const items = enrichCart();
  const total = +items.reduce((sum, i) => sum + i.subtotal, 0).toFixed(2);
  res.json({ success: true, message: "Item removed", data: { items, total, count: items.length } });
});

// DELETE /api/cart — clear entire cart
router.delete("/", (req, res) => {
  clearCart();
  res.json({ success: true, message: "Cart cleared", data: { items: [], total: 0, count: 0 } });
});

module.exports = router;
