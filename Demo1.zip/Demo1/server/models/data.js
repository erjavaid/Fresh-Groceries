// ============================================================
// FreshCart — In-Memory Data Store & Seed Data
// Agent 2: Backend Data Layer
// ============================================================

const products = [
  {
    id: 1,
    name: "Organic Bananas",
    category: "Fruits",
    price: 1.49,
    unit: "bunch",
    image: "🍌",
    inStock: true,
    description: "Sweet, ripe organic bananas. Perfect for smoothies, snacking, or baking."
  },
  {
    id: 2,
    name: "Fresh Strawberries",
    category: "Fruits",
    price: 3.99,
    unit: "pack",
    image: "🍓",
    inStock: true,
    description: "Juicy, hand-picked strawberries. Great for desserts and salads."
  },
  {
    id: 3,
    name: "Avocado",
    category: "Fruits",
    price: 2.49,
    unit: "each",
    image: "🥑",
    inStock: true,
    description: "Creamy Hass avocados, perfect for guacamole or toast."
  },
  {
    id: 4,
    name: "Red Apples",
    category: "Fruits",
    price: 1.99,
    unit: "lb",
    image: "🍎",
    inStock: true,
    description: "Crisp and sweet red apples. A healthy snack anytime."
  },
  {
    id: 5,
    name: "Fresh Broccoli",
    category: "Vegetables",
    price: 2.29,
    unit: "bunch",
    image: "🥦",
    inStock: true,
    description: "Farm-fresh broccoli florets. Packed with vitamins and fiber."
  },
  {
    id: 6,
    name: "Baby Spinach",
    category: "Vegetables",
    price: 3.49,
    unit: "bag",
    image: "🥬",
    inStock: true,
    description: "Tender baby spinach leaves. Perfect for salads and smoothies."
  },
  {
    id: 7,
    name: "Sweet Corn",
    category: "Vegetables",
    price: 0.79,
    unit: "ear",
    image: "🌽",
    inStock: true,
    description: "Golden sweet corn on the cob. Great grilled or boiled."
  },
  {
    id: 8,
    name: "Carrots",
    category: "Vegetables",
    price: 1.29,
    unit: "bag",
    image: "🥕",
    inStock: true,
    description: "Crispy orange carrots. Ideal for snacking, soups, and stews."
  },
  {
    id: 9,
    name: "Whole Milk",
    category: "Dairy",
    price: 4.29,
    unit: "gallon",
    image: "🥛",
    inStock: true,
    description: "Fresh whole milk from local farms. Rich and creamy."
  },
  {
    id: 10,
    name: "Cheddar Cheese",
    category: "Dairy",
    price: 5.99,
    unit: "block",
    image: "🧀",
    inStock: true,
    description: "Aged sharp cheddar cheese. Perfect for sandwiches and cooking."
  },
  {
    id: 11,
    name: "Greek Yogurt",
    category: "Dairy",
    price: 1.79,
    unit: "cup",
    image: "🍶",
    inStock: true,
    description: "Thick and creamy Greek yogurt. High in protein."
  },
  {
    id: 12,
    name: "Sourdough Bread",
    category: "Bakery",
    price: 4.99,
    unit: "loaf",
    image: "🍞",
    inStock: true,
    description: "Artisan sourdough loaf with a crispy crust and tangy flavor."
  },
  {
    id: 13,
    name: "Croissants",
    category: "Bakery",
    price: 3.49,
    unit: "pack of 4",
    image: "🥐",
    inStock: true,
    description: "Buttery, flaky French croissants. Freshly baked daily."
  },
  {
    id: 14,
    name: "Chicken Breast",
    category: "Meat",
    price: 8.99,
    unit: "lb",
    image: "🍗",
    inStock: true,
    description: "Boneless, skinless chicken breast. Lean and versatile."
  },
  {
    id: 15,
    name: "Atlantic Salmon",
    category: "Meat",
    price: 12.99,
    unit: "lb",
    image: "🐟",
    inStock: true,
    description: "Fresh Atlantic salmon fillet. Rich in omega-3 fatty acids."
  },
  {
    id: 16,
    name: "Orange Juice",
    category: "Beverages",
    price: 5.49,
    unit: "carton",
    image: "🧃",
    inStock: true,
    description: "100% pure squeezed orange juice. No added sugars."
  },
  {
    id: 17,
    name: "Green Tea",
    category: "Beverages",
    price: 4.29,
    unit: "box",
    image: "🍵",
    inStock: true,
    description: "Premium Japanese green tea bags. Antioxidant-rich."
  },
  {
    id: 18,
    name: "Pasta",
    category: "Pantry",
    price: 1.99,
    unit: "box",
    image: "🍝",
    inStock: true,
    description: "Italian penne pasta. Made with durum wheat semolina."
  },
  {
    id: 19,
    name: "Olive Oil",
    category: "Pantry",
    price: 7.99,
    unit: "bottle",
    image: "🫒",
    inStock: true,
    description: "Extra virgin olive oil. Cold-pressed from premium olives."
  },
  {
    id: 20,
    name: "Eggs",
    category: "Dairy",
    price: 3.99,
    unit: "dozen",
    image: "🥚",
    inStock: true,
    description: "Free-range large eggs. Farm fresh and hormone-free."
  }
];

// In-memory cart (array of { productId, quantity })
let cart = [];

// In-memory orders list
let orders = [];
let nextOrderId = 1001;

module.exports = {
  products,
  cart,
  orders,
  getNextOrderId: () => nextOrderId++,
  clearCart: () => { cart.length = 0; },
  setCart: (newCart) => {
    cart.length = 0;
    newCart.forEach(item => cart.push(item));
  }
};
