// ============================================================
// FreshCart — Products Module
// Agent 3: Frontend
// ============================================================

const Products = (() => {
  let currentCategory = "All";
  let searchTimeout = null;

  // ── Render a single product card ──
  function createCard(product) {
    const card = document.createElement("div");
    card.className = "product-card";
    card.id = `product-${product.id}`;
    card.innerHTML = `
      <div class="product-emoji">${product.image}</div>
      <span class="product-category">${product.category}</span>
      <h3 class="product-name">${product.name}</h3>
      <p class="product-description">${product.description}</p>
      <div class="product-bottom">
        <div>
          <span class="product-price">$${product.price.toFixed(2)}</span>
          <span class="product-unit">/ ${product.unit}</span>
        </div>
        <button class="btn-add-cart" id="add-btn-${product.id}" onclick="Products.addToCart(${product.id})">
          Add
        </button>
      </div>
    `;
    return card;
  }

  // ── Load & render products ──
  async function loadProducts() {
    const grid = document.getElementById("products-grid");
    const empty = document.getElementById("no-products");
    const search = document.getElementById("search-input").value.trim();

    grid.innerHTML = '<div class="loading-spinner"></div>';
    empty.classList.add("hidden");

    try {
      const res = await API.getProducts(currentCategory, search);
      grid.innerHTML = "";

      if (res.data.length === 0) {
        empty.classList.remove("hidden");
        return;
      }

      // Stagger card animations
      res.data.forEach((product, i) => {
        const card = createCard(product);
        card.style.opacity = "0";
        card.style.transform = "translateY(20px)";
        grid.appendChild(card);

        setTimeout(() => {
          card.style.transition = "opacity 0.4s ease, transform 0.4s ease";
          card.style.opacity = "1";
          card.style.transform = "translateY(0)";
        }, i * 60);
      });
    } catch (err) {
      grid.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:40px;">Failed to load products.</p>';
    }
  }

  // ── Load & render category filters ──
  async function loadCategories() {
    const container = document.getElementById("category-filters");
    try {
      const res = await API.getCategories();
      container.innerHTML = "";
      res.data.forEach((cat) => {
        const pill = document.createElement("button");
        pill.className = `filter-pill${cat === currentCategory ? " active" : ""}`;
        pill.id = `filter-${cat.toLowerCase().replace(/\s+/g, "-")}`;
        pill.textContent = cat;
        pill.addEventListener("click", () => {
          currentCategory = cat;
          document.querySelectorAll(".filter-pill").forEach((p) => p.classList.remove("active"));
          pill.classList.add("active");
          loadProducts();
        });
        container.appendChild(pill);
      });
    } catch (err) {
      console.error("Failed to load categories:", err);
    }
  }

  // ── Add to cart ──
  async function addToCart(productId) {
    const btn = document.getElementById(`add-btn-${productId}`);
    try {
      btn.textContent = "Adding...";
      btn.disabled = true;

      await API.addToCart(productId);
      await Cart.refresh();

      // Visual feedback
      btn.textContent = "✓ Added";
      btn.classList.add("added");
      App.showToast("Added to cart!", "success");

      // Bump cart badge
      const badge = document.getElementById("cart-badge");
      badge.classList.add("bump");
      setTimeout(() => badge.classList.remove("bump"), 300);

      setTimeout(() => {
        btn.textContent = "Add";
        btn.classList.remove("added");
        btn.disabled = false;
      }, 1500);
    } catch (err) {
      btn.textContent = "Add";
      btn.disabled = false;
      App.showToast("Failed to add item", "error");
    }
  }

  // ── Search with debounce ──
  function initSearch() {
    const input = document.getElementById("search-input");
    input.addEventListener("input", () => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => loadProducts(), 350);
    });
  }

  return {
    loadProducts,
    loadCategories,
    addToCart,
    initSearch,
  };
})();
