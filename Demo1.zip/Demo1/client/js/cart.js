// ============================================================
// FreshCart — Cart Module
// Agent 3: Frontend
// ============================================================

const Cart = (() => {
  let isOpen = false;

  // ── Toggle cart drawer ──
  function toggle() {
    isOpen = !isOpen;
    document.getElementById("cart-drawer").classList.toggle("open", isOpen);
    document.getElementById("cart-overlay").classList.toggle("open", isOpen);
    document.body.style.overflow = isOpen ? "hidden" : "";
    if (isOpen) refresh();
  }

  function close() {
    isOpen = false;
    document.getElementById("cart-drawer").classList.remove("open");
    document.getElementById("cart-overlay").classList.remove("open");
    document.body.style.overflow = "";
  }

  // ── Refresh cart display ──
  async function refresh() {
    try {
      const res = await API.getCart();
      const { items, total, count } = res.data;

      // Update badge
      const badge = document.getElementById("cart-badge");
      badge.textContent = count;

      // Update total
      document.getElementById("cart-total").textContent = `$${total.toFixed(2)}`;

      // Toggle empty state
      const itemsContainer = document.getElementById("cart-items");
      const emptyState = document.getElementById("cart-empty");
      const footer = document.getElementById("cart-footer");
      const checkoutBtn = document.getElementById("btn-checkout");

      if (count === 0) {
        itemsContainer.classList.add("hidden");
        emptyState.classList.remove("hidden");
        footer.style.display = "none";
      } else {
        itemsContainer.classList.remove("hidden");
        emptyState.classList.add("hidden");
        footer.style.display = "";
        checkoutBtn.disabled = false;
      }

      // Render items
      itemsContainer.innerHTML = "";
      items.forEach((item) => {
        const el = document.createElement("div");
        el.className = "cart-item";
        el.id = `cart-item-${item.productId}`;
        el.innerHTML = `
          <span class="cart-item-emoji">${item.image}</span>
          <div class="cart-item-info">
            <div class="cart-item-name">${item.name}</div>
            <div class="cart-item-price">$${item.subtotal.toFixed(2)}</div>
          </div>
          <div class="cart-item-qty">
            <button class="qty-btn" onclick="Cart.updateQty(${item.productId}, ${item.quantity - 1})" aria-label="Decrease quantity">−</button>
            <span class="qty-value">${item.quantity}</span>
            <button class="qty-btn" onclick="Cart.updateQty(${item.productId}, ${item.quantity + 1})" aria-label="Increase quantity">+</button>
          </div>
          <button class="cart-item-remove" onclick="Cart.remove(${item.productId})" aria-label="Remove item">🗑</button>
        `;
        itemsContainer.appendChild(el);
      });
    } catch (err) {
      console.error("Failed to refresh cart:", err);
    }
  }

  // ── Update item quantity ──
  async function updateQty(productId, quantity) {
    try {
      if (quantity <= 0) {
        await API.removeCartItem(productId);
        App.showToast("Item removed", "success");
      } else {
        await API.updateCartItem(productId, quantity);
      }
      await refresh();
    } catch (err) {
      App.showToast("Failed to update quantity", "error");
    }
  }

  // ── Remove single item ──
  async function remove(productId) {
    try {
      const el = document.getElementById(`cart-item-${productId}`);
      if (el) {
        el.style.transition = "all 0.3s ease";
        el.style.opacity = "0";
        el.style.transform = "translateX(40px)";
      }

      setTimeout(async () => {
        await API.removeCartItem(productId);
        await refresh();
        App.showToast("Item removed", "success");
      }, 250);
    } catch (err) {
      App.showToast("Failed to remove item", "error");
    }
  }

  // ── Clear entire cart ──
  async function clearAll() {
    try {
      await API.clearCart();
      await refresh();
      App.showToast("Cart cleared", "success");
    } catch (err) {
      App.showToast("Failed to clear cart", "error");
    }
  }

  // ── Init event listeners ──
  function init() {
    document.getElementById("cart-toggle").addEventListener("click", toggle);
    document.getElementById("cart-close").addEventListener("click", close);
    document.getElementById("cart-overlay").addEventListener("click", close);
    document.getElementById("btn-clear-cart").addEventListener("click", clearAll);

    // Initial badge load
    refresh();
  }

  return { init, toggle, close, refresh, updateQty, remove, clearAll };
})();
