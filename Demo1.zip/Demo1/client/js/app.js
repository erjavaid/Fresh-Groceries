// ============================================================
// FreshCart — App Router & Initialization
// Agent 3: Frontend  |  Agent 4: Integration
// ============================================================

const App = (() => {
  let currentPage = "products";

  // ── Page Navigation ──
  function navigate(page) {
    currentPage = page;

    // Toggle page visibility
    document.querySelectorAll(".page").forEach((p) => p.classList.remove("active"));
    document.getElementById(`page-${page}`).classList.add("active");

    // Toggle nav link state
    document.querySelectorAll(".nav-link").forEach((l) => l.classList.remove("active"));
    const activeLink = document.querySelector(`[data-page="${page}"]`);
    if (activeLink) activeLink.classList.add("active");

    // Toggle hero & filters visibility
    const hero = document.getElementById("hero-section");
    const filters = document.getElementById("filters-section");
    if (page === "products") {
      hero.style.display = "";
      filters.style.display = "";
    } else {
      hero.style.display = "none";
      filters.style.display = "none";
    }

    // Load page-specific data
    if (page === "orders") {
      Checkout.loadOrders();
    }
  }

  // ── Toast Notifications ──
  function showToast(message, type = "success") {
    const container = document.getElementById("toast-container");
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <span class="toast-icon">${type === "success" ? "✅" : "❌"}</span>
      <span>${message}</span>
    `;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = "toastOut 0.3s ease forwards";
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  // ── Initialize the App ──
  async function init() {
    // Nav links
    document.querySelectorAll(".nav-link").forEach((link) => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        navigate(link.dataset.page);
      });
    });

    // Logo click → products
    document.getElementById("logo-link").addEventListener("click", (e) => {
      e.preventDefault();
      navigate("products");
      window.scrollTo({ top: 0, behavior: "smooth" });
    });

    // Hero CTA
    document.getElementById("hero-shop-btn").addEventListener("click", () => {
      document.getElementById("filters-section").scrollIntoView({ behavior: "smooth" });
    });

    // Init modules
    Cart.init();
    Checkout.init();
    Products.initSearch();

    // Load initial data
    await Products.loadCategories();
    await Products.loadProducts();

    console.log(
      "%c🛒 FreshCart loaded successfully!",
      "color: #22c55e; font-size: 16px; font-weight: bold;"
    );
  }

  // ── Boot ──
  document.addEventListener("DOMContentLoaded", init);

  return { navigate, showToast };
})();
