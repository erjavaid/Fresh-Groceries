// ============================================================
// FreshCart — Checkout & Orders Module
// Agent 3: Frontend
// ============================================================

const Checkout = (() => {
  // ── Open checkout modal ──
  async function open() {
    try {
      const res = await API.getCart();
      const { items, total } = res.data;

      if (items.length === 0) {
        App.showToast("Your cart is empty!", "error");
        return;
      }

      // Build checkout summary
      const body = document.getElementById("checkout-body");
      body.innerHTML = `
        <div class="checkout-items">
          ${items
            .map(
              (item) => `
            <div class="checkout-item">
              <span class="checkout-item-emoji">${item.image}</span>
              <div class="checkout-item-info">
                <div class="checkout-item-name">${item.name}</div>
                <div class="checkout-item-meta">Qty: ${item.quantity} × $${item.price.toFixed(2)}</div>
              </div>
              <span class="checkout-item-subtotal">$${item.subtotal.toFixed(2)}</span>
            </div>
          `
            )
            .join("")}
        </div>
        <div class="checkout-total">
          <span>Order Total</span>
          <span class="checkout-total-value">$${total.toFixed(2)}</span>
        </div>
      `;

      // Show modal
      document.getElementById("checkout-overlay").classList.remove("hidden");
      Cart.close();
    } catch (err) {
      App.showToast("Failed to load checkout", "error");
    }
  }

  // ── Close checkout modal ──
  function close() {
    document.getElementById("checkout-overlay").classList.add("hidden");
  }

  // ── Place order ──
  async function confirm() {
    const btn = document.getElementById("checkout-confirm");
    btn.textContent = "Placing Order...";
    btn.disabled = true;

    try {
      const res = await API.placeOrder();
      close();

      // Show success modal
      const successContent = document.getElementById("success-content");
      successContent.innerHTML = `
        <span class="success-icon">🎉</span>
        <h2 class="success-title">Order Placed!</h2>
        <p class="success-message">
          Your grocery order has been confirmed and is being prepared.
        </p>
        <span class="success-order-id">Order #${res.data.id}</span>
        <p class="success-message">
          Total: <strong>$${res.data.total.toFixed(2)}</strong> · ${res.data.items.length} item${res.data.items.length > 1 ? "s" : ""}
        </p>
        <button class="success-close-btn" id="success-close-btn" onclick="Checkout.closeSuccess()">
          Continue Shopping
        </button>
      `;

      document.getElementById("success-overlay").classList.remove("hidden");
      await Cart.refresh();
    } catch (err) {
      App.showToast("Failed to place order", "error");
    } finally {
      btn.textContent = "Place Order";
      btn.disabled = false;
    }
  }

  // ── Close success modal ──
  function closeSuccess() {
    document.getElementById("success-overlay").classList.add("hidden");
  }

  // ── Load orders page ──
  async function loadOrders() {
    const list = document.getElementById("orders-list");
    const empty = document.getElementById("no-orders");

    list.innerHTML = '<div class="loading-spinner"></div>';
    empty.classList.add("hidden");

    try {
      const res = await API.getOrders();

      if (res.data.length === 0) {
        list.innerHTML = "";
        empty.classList.remove("hidden");
        return;
      }

      list.innerHTML = res.data
        .map(
          (order) => `
          <div class="order-card" id="order-${order.id}">
            <div class="order-header">
              <span class="order-id">Order #${order.id}</span>
              <span class="order-date">${new Date(order.createdAt).toLocaleString()}</span>
              <span class="order-status ${order.status}">${order.status}</span>
            </div>
            <div class="order-items">
              ${order.items
                .map(
                  (item) =>
                    `<span class="order-item-chip">${item.image} ${item.name} ×${item.quantity}</span>`
                )
                .join("")}
            </div>
            <div class="order-total">$${order.total.toFixed(2)}</div>
          </div>
        `
        )
        .join("");
    } catch (err) {
      list.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:40px;">Failed to load orders.</p>';
    }
  }

  // ── Init event listeners ──
  function init() {
    document.getElementById("btn-checkout").addEventListener("click", open);
    document.getElementById("checkout-close").addEventListener("click", close);
    document.getElementById("checkout-cancel").addEventListener("click", close);
    document.getElementById("checkout-confirm").addEventListener("click", confirm);
    document.getElementById("success-overlay").addEventListener("click", (e) => {
      if (e.target === e.currentTarget) closeSuccess();
    });
    document.getElementById("checkout-overlay").addEventListener("click", (e) => {
      if (e.target === e.currentTarget) close();
    });
  }

  return { init, open, close, confirm, closeSuccess, loadOrders };
})();
