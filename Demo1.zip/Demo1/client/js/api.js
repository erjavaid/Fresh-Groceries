// ============================================================
// FreshCart — API Client
// Agent 3: Frontend
// ============================================================

const API = (() => {
  const BASE = "/api";

  async function request(endpoint, options = {}) {
    try {
      const res = await fetch(`${BASE}${endpoint}`, {
        headers: { "Content-Type": "application/json" },
        ...options,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");
      return data;
    } catch (err) {
      console.error(`API Error [${endpoint}]:`, err);
      throw err;
    }
  }

  return {
    // Products
    getProducts: (category, search) => {
      const params = new URLSearchParams();
      if (category && category !== "All") params.set("category", category);
      if (search) params.set("search", search);
      const qs = params.toString();
      return request(`/products${qs ? "?" + qs : ""}`);
    },
    getCategories: () => request("/products/categories/list"),

    // Cart
    getCart: () => request("/cart"),
    addToCart: (productId, quantity = 1) =>
      request("/cart", {
        method: "POST",
        body: JSON.stringify({ productId, quantity }),
      }),
    updateCartItem: (productId, quantity) =>
      request(`/cart/${productId}`, {
        method: "PUT",
        body: JSON.stringify({ quantity }),
      }),
    removeCartItem: (productId) =>
      request(`/cart/${productId}`, { method: "DELETE" }),
    clearCart: () => request("/cart", { method: "DELETE" }),

    // Orders
    placeOrder: () => request("/orders", { method: "POST" }),
    getOrders: () => request("/orders"),
  };
})();
